package ejercicios_practicos;
import java.util.Scanner;
public class main_10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado=new Scanner(System.in);
		
		// Obtener el promedio de N notas
		
		int promedio=0,notas_totales=0;
		int not_1=0,not_2=0,not_3=0,not_4=0;
		System.out.println("Ingrese la nota1:");
		not_1=teclado.nextInt();
		System.out.println("Ingrese la nota2:");
		not_2=teclado.nextInt();
		System.out.println("Ingrese la nota3:");
		not_3=teclado.nextInt();
		System.out.println("Ingrese la nota4:");
		not_4=teclado.nextInt();
		
  notas_totales=not_1+not_2+not_3+not_4;
  promedio=notas_totales/4;
  System.out.println("El promedio es:"+promedio);
	}
	
}

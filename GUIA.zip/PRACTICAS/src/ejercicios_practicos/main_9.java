package ejercicios_practicos;
import java.util.Scanner;
public class main_9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado=new Scanner(System.in);
		// Calcular el volumen de un cilindro conociendo su radio y altura.
		
		float vol=0,radio=0,h=0,area;
		System.out.println("Ingrese el radio:");
		radio=teclado.nextInt();
		System.out.println("Ingrese la altura:");
		h=teclado.nextInt();		
		area=(int)(2*Math.PI*radio*(radio+h));
		System.out.println("El area es:"+area+"cm");
		
		
	}
	

}

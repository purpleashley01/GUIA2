package ejercicios_practicos;
import java.util.Scanner;
public class main_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Scanner teclado=new Scanner(System.in) ;
  
  int radio=0;
  float per=0;
  System.out.println("Ingrese el radio de la ciercunferenci:");
  radio=teclado.nextInt();
  //perimetro
  per=(int)(2*Math.PI*radio);
  System.out.println("El perimetro de la circunferencia es:"+per);
  
	}

}

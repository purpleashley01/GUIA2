package ejercicios_practicos;
import java.util.Scanner;
public class min_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado=new Scanner(System.in);
		
		int raiz=0,num=0;
		System.out.println("Ingrese un numero:");
		num=teclado.nextInt();
		raiz=(int)(Math.sqrt(num));
		
		System.out.println("La raiz es:"+raiz);
		
	}

}

package ejercicios_practicos;
import java.util.Scanner;
public class main_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner teclado=new Scanner(System.in);
		
		 //Calcular el área de un triángulo conociendo sus tres lados.
		
		int area=0,b=0,h=0;
		
		System.out.println("Ingrese la base:");
		b=teclado.nextInt();
		System.out.println("Ingrese la altura:");
		h=teclado.nextInt();
		
		//area
		area=b*h/2;
		System.out.println("La area del triangulo es:"+area+"cm");
		
		
		
		
	}

}

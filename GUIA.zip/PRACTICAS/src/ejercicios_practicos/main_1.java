package ejercicios_practicos;
import java.util.Scanner;
public class main_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Scanner teclado=new Scanner (System.in);	
 
    
 int H=0,B=0,A=0;	
 
    System.out.println("Ingrese la altura del rectangulo:");
    H=teclado.nextInt();
    System.out.println("Ingrese la base del rectangulo:");
    B=teclado.nextInt();
   //area
 
 A=B*H;
 B=A/H;
 H=A/B;
    System.out.println("\nLa area de su rectangulo es:" +A+"\nLa base es:" +B+"\nLa altura es:"+H);
 
 
	}

}

package ejercicios_practicos;
import java.util.Scanner;
public class main_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner teclado=new Scanner (System.in);
		
		/*Evaluar la Función Y= 5X^4 + 2X^3 + 3X^2 + 7 para el valor de 
		*a) X=1;
		*b) X un número cualquiera.
		*/
		int X=1,Y=0;
		Y=(int)(5*1^4 + 2*1^3 + 3*1^2 + 7);
		
		System.out.println("El valor de Y es:"+ Y);
		
		
	}

}

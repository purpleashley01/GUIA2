package ejercicios_practicos;
import java.util.Scanner;
public class main_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado=new Scanner(System.in);
		
		//Convertir X grados Fahrenheit a grados Celsius. Celsius= 5/9 (Fahrenheit -323)
		
	float x=0,cel,fah;
		System.out.println("Ingrese los grados fahrenheit:");
		x=teclado.nextFloat();
		//Formula
		cel=(float)((x-32)/1.8);
		System.out.println("Su grado es celsius es:"+cel+"°");
		
		
		
		
		
	}

}

package ejercicios_practicos;
import java.util.Scanner;
public class main_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado=new Scanner(System.in);
		int n=0;
		double lb=0;
		double kg=lb;
		System.out.println("Ingrese el valor en Kilogramos: ");
		n=teclado.nextInt();
		//formula
		lb=(n*2.20462)/1;
		
		System.out.println("La respuesta es:"+lb+"lb");
		
		
	}

}

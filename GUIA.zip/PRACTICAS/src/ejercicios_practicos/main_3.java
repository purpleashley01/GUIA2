package ejercicios_practicos;
import java.util.Scanner;
public class main_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Scanner teclado=new Scanner (System.in);	
  
		//3. Determine el valor de Y= X*C-2 donde C es una constante con valor C=2.5.
       //a) Sabiendo que X=2;
//b) Considerando a X un valor cualquiera.
  
 int X=2,Y=0;
float C= (float)2.5;
		
 Y= (int)(X*C-2);
 System.out.println("El valor de Y es:"+Y);
		
		
	}

}
